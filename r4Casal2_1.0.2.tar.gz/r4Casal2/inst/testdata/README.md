## About

This files have been downloaded from the latest Casal2 artifact. To update the testdata just redownload the artifacts and copy them here.

There was too much admin to automate this.