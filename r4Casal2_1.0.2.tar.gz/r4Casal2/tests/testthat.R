
library(testthat)
library(r4Casal2)

test_check("r4Casal2")
