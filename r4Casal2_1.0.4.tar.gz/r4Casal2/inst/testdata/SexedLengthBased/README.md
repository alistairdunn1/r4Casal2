This unit test will test a range of length based model functionality. This model has a CASAL comparison which gives very close MPD estimates and likelihood fits.
This unit test has simulated data based on the the CASAL assessment and aims to freeze this tested functionality.

Two sexes
Annual cycle - three time-steps
Processes
	- Three tag release
	- Three fisheries
	- BH recruitment
	- Growth
Observations 
	- Proportions_at_length
	- Process Removals by length
	- relative abundance
	- proportios mature
	- tag recapture for growth
